package contagem.truco.jhonatan.davi.app.contagemapp.contagem.contagem.app.view.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.AppCompatCheckBox;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.List;

import contagem.truco.jhonatan.davi.app.contagemapp.R;
import contagem.truco.jhonatan.davi.app.contagemapp.contagem.contagem.app.presenter.ContagemPresenter;

public class RecyclerViewAdapterContagem extends RecyclerView.Adapter <RecyclerViewAdapterContagem.ViewHolder>{

    private List <Object> objets;

    private ContagemPresenter presenter;

    public RecyclerViewAdapterContagem(ContagemPresenter presenter, List <Object> objects) {
        this.presenter = presenter;
        this.objets = objects;

    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_recycler_adapter_contagem, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int position) {

        Object o = objets.get(position);

        holder._number_we.setText(o.toString());
        holder._number_they.setText(o.toString());

    }

    @Override
    public int getItemCount() {
        return objets.size();
    }

    public void setItemList(List <Object> objects) {
        this.objets = objects;
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        private AppCompatTextView _number_we;
        private AppCompatTextView _number_they;

        private AppCompatCheckBox _check_they;

        ViewHolder(View itemView) {
            super(itemView);

            _number_we   = itemView.findViewById(R.id.item_recycler_view_adapter_contagem_number_we);
            _number_they = itemView.findViewById(R.id.item_recycler_view_adapter_contagem_number_they);

            _check_they  = itemView.findViewById(R.id.item_recycler_view_adapter_contagem_check_they);
        }
    }
}