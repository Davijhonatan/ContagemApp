package contagem.truco.jhonatan.davi.app.contagemapp.contagem.AsyncTask;

import android.app.Activity;
import android.content.Context;
import android.os.AsyncTask;

public abstract class AsyncTaskRunner <T, TU> extends AsyncTask<T, Integer, TU> {

    public IAsyncTaskRunner<TU> _asyncTaskRunner;

    public AsyncTaskRunner(IAsyncTaskRunner<TU> asyncTaskRunner) {
        _asyncTaskRunner = asyncTaskRunner;
    }

    protected Context getContext() {
        return _asyncTaskRunner.getContext();
    }

    protected Activity getActivity() {
        return _asyncTaskRunner.getActivity();
    }

    @Override
    protected void onPreExecute() {
        _asyncTaskRunner.taskStarting();
    }

    @Override
    public void onProgressUpdate(Integer... value) {
        _asyncTaskRunner.taskProgressUpdate(value);
    }

    @Override
    protected void onPostExecute(TU result) {
        _asyncTaskRunner.taskCompleted(result);
    }


}