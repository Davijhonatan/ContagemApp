package contagem.truco.jhonatan.davi.app.contagemapp.contagem.AsyncTask;

import android.app.Activity;
import android.content.Context;

public interface IAsyncTaskRunner<T> {

    Context getContext();
    Activity getActivity();
    void taskStarting();
    void taskCompleted(T result);
    void taskProgressUpdate(Integer... values);
    void onCancelled();
}
