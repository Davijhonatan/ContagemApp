package contagem.truco.jhonatan.davi.app.contagemapp.contagem.contagem.app.presenter;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import java.util.List;

import contagem.truco.jhonatan.davi.app.contagemapp.contagem.contagem.app.view.adapter.RecyclerViewAdapterContagem;

public class ContagemPresenterImpl implements ContagemPresenter {

    private Activity activity;
    private Context context;
    private RecyclerView recyclerView;

    private Color color;


    public ContagemPresenterImpl(Context context, Activity activity) {
        this.context = context;
        this.activity = activity;
    }

    @Override
    public Activity getActivity() {
        return activity;
    }

    @Override
    public Context getContext() {
        return context;
    }


    @Override
    public Color getColor() {
        return color;
    }

    @Override
    public void view(RecyclerView recyclerView) {
        this.recyclerView = recyclerView;

    }

    @Override
    public void toast(String message, int status) {
       // Toast.makeText(getContext(), message, Toast.LENGTH_LONG, status).show();
    }
}