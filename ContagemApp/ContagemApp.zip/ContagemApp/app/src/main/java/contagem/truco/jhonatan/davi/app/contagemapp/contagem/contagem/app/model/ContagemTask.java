package contagem.truco.jhonatan.davi.app.contagemapp.contagem.contagem.app.model;

import java.util.ArrayList;
import java.util.List;

import contagem.truco.jhonatan.davi.app.contagemapp.contagem.AsyncTask.AsyncTaskRunner;
import contagem.truco.jhonatan.davi.app.contagemapp.contagem.AsyncTask.IAsyncTaskRunner;
import contagem.truco.jhonatan.davi.app.contagemapp.contagem.view.TaskConstant;

public class ContagemTask extends AsyncTaskRunner<Object, Object> {

    public ContagemTask(IAsyncTaskRunner<Object> asyncTaskRunner) {
        super(asyncTaskRunner);
    }

    @Override
    protected Object doInBackground(Object... params) {

        Integer param = (Integer) params[0];

        List<Object> result = new ArrayList<>();

        result.add(param);

        switch (param) {

            case TaskConstant.CONTAGEM:

                List<Object> objects = new ArrayList<>();

                objects.add("1");
                objects.add("2");
                objects.add("3");
                objects.add("4");
                objects.add("5");
                objects.add("6");
                objects.add("7");
                objects.add("8");
                objects.add("9");
                objects.add("10");
                objects.add("11");
                objects.add("12");

                result.add(objects);

                break;

        }

        return result;
    }
}
