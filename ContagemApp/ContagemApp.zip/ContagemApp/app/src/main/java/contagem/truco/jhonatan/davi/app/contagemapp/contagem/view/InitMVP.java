package contagem.truco.jhonatan.davi.app.contagemapp.contagem.view;

public interface InitMVP {

    void init();
    void load();
    void task();
}
