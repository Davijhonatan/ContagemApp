package contagem.truco.jhonatan.davi.app.contagemapp.contagem.contagem.app.presenter;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.provider.CalendarContract;
import android.support.annotation.ColorRes;
import android.support.v4.graphics.ColorUtils;
import android.support.v7.widget.RecyclerView;

import java.util.List;

import contagem.truco.jhonatan.davi.app.contagemapp.contagem.contagem.app.view.adapter.RecyclerViewAdapterContagem;

public interface ContagemPresenter {

    Activity getActivity();

    Context getContext();

    Color getColor();

    void toast(String message, int success);

    void view(RecyclerView recyclerView);





}
