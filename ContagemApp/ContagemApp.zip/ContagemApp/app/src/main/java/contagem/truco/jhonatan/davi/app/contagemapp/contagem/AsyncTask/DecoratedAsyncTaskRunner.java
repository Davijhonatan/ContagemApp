package contagem.truco.jhonatan.davi.app.contagemapp.contagem.AsyncTask;

import android.app.Activity;
import android.content.Context;

public class DecoratedAsyncTaskRunner<T> {
    private IAsyncTaskRunner<T> _decoratedRunner;

    public DecoratedAsyncTaskRunner(IAsyncTaskRunner<T> decoratedRunner) {
        _decoratedRunner = decoratedRunner;
    }

    public Context getContext() {
        return _decoratedRunner.getContext();
    }

    public Activity getActivity() {
        return _decoratedRunner.getActivity();
    }

    public void taskStarting() {
        _decoratedRunner.taskStarting();
    }

    public void taskCompleted(T result) {
        _decoratedRunner.taskCompleted(result);
    }

    public void taskProgressUpdate(Integer... value){
        _decoratedRunner.taskProgressUpdate(value);
    }
}