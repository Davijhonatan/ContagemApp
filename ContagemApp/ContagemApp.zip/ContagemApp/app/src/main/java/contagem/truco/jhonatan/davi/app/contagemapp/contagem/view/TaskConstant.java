package contagem.truco.jhonatan.davi.app.contagemapp.contagem.view;

public interface TaskConstant {


    String SUCESSO  = "Sucesso";
    String MENSAGEM = "Mensagem";
    String DATA     = "Data";
    String NULL     = "null";
    String LISTA     = "Lista";

    int CONTAGEM = 1;
}