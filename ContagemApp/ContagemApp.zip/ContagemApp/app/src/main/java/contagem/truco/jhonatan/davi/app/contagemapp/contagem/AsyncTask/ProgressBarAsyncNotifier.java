package contagem.truco.jhonatan.davi.app.contagemapp.contagem.AsyncTask;

import android.app.Activity;
import android.content.Context;
import android.support.v4.app.FragmentManager;

public class ProgressBarAsyncNotifier<T> extends DecoratedAsyncTaskRunner<T> implements IAsyncTaskRunner<T> {

    private String 			    _titleProgress;
    private String 			    _messageProgress;
    private IAsyncTaskRunner<T> _decoratedRunner;

    private FragmentManager _supportFragmentManager;

    private Boolean cancel         = true;
    private Boolean progress       = true;
    private Boolean styleProgress  = false;
    private Boolean exibirMensagem = true;
    private Boolean isVisibleProgress = true;
    private Boolean isTaskStarting    = true;
    private Boolean isFragmentManager = true;
    private Boolean isTaskProgressUpdate = false;
    public  Boolean isIndeterminate      = true;

    //private CircleProgressView     _circleProgressView;

   /* private MaterialDialog.Builder  _builder;
    private MaterialDialog          _materialDialog;*/

    public ProgressBarAsyncNotifier(IAsyncTaskRunner<T> decoratedRunner,String titleProgress, String messageProgress) {
        super(decoratedRunner);
        _decoratedRunner = decoratedRunner;
        _titleProgress   = titleProgress;
        _messageProgress = messageProgress;
    }

    public void setTitleProgress(String _titleProgress) {
        this._titleProgress = _titleProgress;
    }

    public void setMessageProgress(String _messageProgress) {
        this._messageProgress = _messageProgress;
    }

    public void setExibirMensagem(Boolean exibirMensagem){
        this.exibirMensagem = exibirMensagem;
    }

    public void setIsVisibleProgress(Boolean isVisibleProgress){
        this.isVisibleProgress = isVisibleProgress;
    }

    public void setCancelable(Boolean cancel){
        this.cancel = cancel;
    }

    public void setProgress(Boolean progress){
        this.progress = progress;
    }

    public void setStyleProgress(Boolean styleProgress){
        this.styleProgress = styleProgress;
    }

    public void setTaskStarting(Boolean isTaskStarting){
        this.isTaskStarting = isTaskStarting;
    }

    public void setTaskProgressUpdate(Boolean isTaskProgressUpdate){
        this.isTaskProgressUpdate = isTaskProgressUpdate;
    }

    public void setIndeterminate(Boolean isIndeterminate){
        this.isIndeterminate = isIndeterminate;
    }

    @Override
    public Context getContext() {
        return null;
    }

    @Override
    public Activity getActivity() {
        return null;
    }

    @Override
    public void taskStarting() {


       /* if (isIndeterminate) {

            _builder = new MaterialDialog.Builder(getContext());
            _builder.title(_titleProgress);
            _builder.cancelable(cancel);
            _builder.content(_messageProgress);
            _builder.progress(true, 0);

            _materialDialog = _builder.show();

        } else {

            _builder = new MaterialDialog.Builder(getContext());
            _builder.title(_titleProgress);
            _builder.cancelable(cancel);
            _builder.content(_messageProgress);
            _builder.progress(false, 100, true);

            _materialDialog = _builder.show();

        }*/


    }

    @Override
    public void taskCompleted(T result) {

   /* if (_materialDialog != null && _materialDialog.isShowing()) {

            try {

                if (getActivity() != null && getActivity() instanceof Activity && !getActivity().isFinishing()) {

                    _materialDialog.dismiss();

                } else if (getContext() instanceof Activity) {

                    if (!((Activity) getContext()).isFinishing()) {
                        _materialDialog.dismiss();
                    }

                }

            } catch (Exception ignored) { }

        }*/

        super.taskCompleted(result);

    }

    @Override
    public void taskProgressUpdate(Integer... value) {
        if (!isIndeterminate) {
            //_materialDialog.setProgress(value[0]);
        }
        super.taskProgressUpdate(value);
    }

    @Override
    public void onCancelled() {

    }

    public void setSupportFragmentManager(FragmentManager supportFragmentManager) {
        this._supportFragmentManager = supportFragmentManager;
    }

    /*public void setCircleProgressView(CircleProgressView _circleProgressView) {
        this._circleProgressView = _circleProgressView;
    }*/
}
