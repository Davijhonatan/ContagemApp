package contagem.truco.jhonatan.davi.app.contagemapp.contagem.contagem.app.view;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import java.util.List;

import contagem.truco.jhonatan.davi.app.contagemapp.R;
import contagem.truco.jhonatan.davi.app.contagemapp.contagem.AsyncTask.IAsyncTaskRunner;
import contagem.truco.jhonatan.davi.app.contagemapp.contagem.AsyncTask.ProgressBarAsyncNotifier;
import contagem.truco.jhonatan.davi.app.contagemapp.contagem.contagem.app.model.ContagemTask;
import contagem.truco.jhonatan.davi.app.contagemapp.contagem.contagem.app.presenter.ContagemPresenter;
import contagem.truco.jhonatan.davi.app.contagemapp.contagem.contagem.app.presenter.ContagemPresenterImpl;
import contagem.truco.jhonatan.davi.app.contagemapp.contagem.view.InitMVP;
import contagem.truco.jhonatan.davi.app.contagemapp.contagem.view.TaskConstant;

public class ContagemActivity extends AppCompatActivity implements InitMVP, IAsyncTaskRunner<Object>, View.OnClickListener{

    private ContagemPresenter presenter;

    private RecyclerView _recycler_view;

    private AppCompatImageView _botao_mais_time_one;
    private AppCompatImageView _botao_mais_time_two;

    private AppCompatImageView _botao_menos_time_one;
    private AppCompatImageView _botao_menos_time_two;

    private AppCompatTextView _placar_time_one;
    private AppCompatTextView _placar_time_two;

    private AppCompatImageView _one_botao_acres_three_ponto;
    private AppCompatImageView _two_botao_acres_three_ponto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.contagem_two_lyout);

        init();
        load();
        task();
    }


    @Override
    public void init() {

        _recycler_view = findViewById(R.id.item_recycler_view_main);

        _botao_mais_time_one = findViewById(R.id.item_view_botao_mais_time_one);
        _botao_mais_time_two = findViewById(R.id.item_view_botao_mais_time_two);

        _botao_menos_time_one = findViewById(R.id.item_view_botao_menos_time_one);
        _botao_menos_time_two = findViewById(R.id.item_view_botao_menos_time_two);

        _placar_time_one = findViewById(R.id.item_view_placar_time_one);
        _placar_time_one.setText("0");

        _placar_time_two = findViewById(R.id.item_view_placar_time_two);
        _placar_time_two.setText("0");

        _one_botao_acres_three_ponto = findViewById(R.id.item_view_time_one_botao_acres_three_ponto);
        _two_botao_acres_three_ponto = findViewById(R.id.item_view_time_two_botao_acres_three_ponto);

        _botao_mais_time_one.setOnClickListener(this);
        _botao_menos_time_one.setOnClickListener(this);

        _botao_menos_time_two.setOnClickListener(this);
        _botao_mais_time_two.setOnClickListener(this);

    }

    @Override
    public void load() {

        presenter = new ContagemPresenterImpl(getContext(), getActivity());
        presenter.view(_recycler_view);


    }

    @SuppressWarnings({"unchecked", "all"})
    public void acaoAcresThreePonto (){

        _one_botao_acres_three_ponto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Integer quant = Integer.valueOf(_placar_time_one.getText().toString());

                if (quant >=0 && quant <=9){

                    Integer valor = quant + 3;
                    String soma   = String.valueOf(valor);

                    _placar_time_one.setText(soma.toString());
                }else {
                    Integer valor = quant + 0;
                    String soma   = String.valueOf(valor);

                    _placar_time_one.setText(soma.toString());
                }

            }
        });

        _two_botao_acres_three_ponto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Integer quant = Integer.valueOf(_placar_time_two.getText().toString());

                if (quant >= 0 && quant <= 9){

                    Integer soma   = quant + 3;
                    String  result = String.valueOf(soma);

                    _placar_time_two.setText(result.toString());

                }else {

                Integer soma   = quant + 0;
                String  result = String.valueOf(soma);

                _placar_time_two.setText(result.toString());
                }
            }
        });

    }

    @Override
    public void task() {
        acaoAcresThreePonto();

    }

    @Override
    public Context getContext() {
        return this;
    }

    @Override
    public Activity getActivity() {
        return this;
    }

    @Override
    public void taskStarting() {

    }

    @SuppressWarnings("all")
    @Override
    public void taskCompleted(Object result) {

        List<Object> resultTask = (List<Object>) result;

        Integer integer = (Integer) resultTask.get(0);

        switch (integer) {

            case TaskConstant.CONTAGEM:

                acaoAcresThreePonto();

                break;
        }
    }

    @Override
    public void taskProgressUpdate(Integer... values) {

    }

    @Override
    public void onCancelled() {

    }

    @SuppressWarnings("unchecked")
    public ContagemTask getTask() {

        ProgressBarAsyncNotifier progressBarAsyncNotifier =  new ProgressBarAsyncNotifier<>(this, "Aguarde", "Carregando dados...");

        return new ContagemTask(progressBarAsyncNotifier);
    }

    @SuppressWarnings("unchecked")
    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.item_view_botao_mais_time_one:

                Integer quantTimeOne = Integer.valueOf(_placar_time_one.getText().toString());

                if (quantTimeOne >= 0 && quantTimeOne <= 11) {

                    Integer valor = quantTimeOne + 1;
                    String subtracao = String.valueOf(valor);

                    _placar_time_one.setText(subtracao);

                } else {

                    Integer valor = quantTimeOne - 0;
                    String subtracao = String.valueOf(valor);

                    _placar_time_one.setText(subtracao);
                }

                break;

            case R.id.item_view_botao_mais_time_two:

                Integer quantOne = Integer.valueOf(_placar_time_two.getText().toString());

                if (quantOne >= 0 && quantOne <= 11) {

                    Integer valor = quantOne + 1;
                    String subtracao = String.valueOf(valor);

                    _placar_time_two.setText(subtracao);

                } else {

                    Integer valor = quantOne - 0;
                    String subtracao = String.valueOf(valor);

                    _placar_time_two.setText(subtracao);
                }


                break;

            case R.id.item_view_botao_menos_time_one:

                Integer quantTimeTwo = Integer.valueOf(_placar_time_one.getText().toString());

                if (quantTimeTwo >= 1 && quantTimeTwo <= 12) {

                    Integer valor = quantTimeTwo - 1;
                    String sub = String.valueOf(valor);

                    _placar_time_one.setText(sub);

                } else {

                    Integer valor = quantTimeTwo;
                    String sub = String.valueOf(valor);

                    _placar_time_one.setText(sub);
                }

                break;

            case R.id.item_view_botao_menos_time_two:

                Integer quantTwo = Integer.valueOf(_placar_time_two.getText().toString());

                if (quantTwo >= 1 && quantTwo <= 12) {

                    Integer valor = quantTwo - 1;
                    String sub = String.valueOf(valor);

                    _placar_time_two.setText(sub);

                } else {

                    Integer valor = quantTwo;
                    String sub = String.valueOf(valor);

                    _placar_time_two.setText(sub);
                }

                break;

        }

    }

}
